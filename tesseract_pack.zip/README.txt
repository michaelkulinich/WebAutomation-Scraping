Hey CS298 group!
Do these thing to convert an image to a text!

1. Make sure you have the latest version of python
Python 3.6 or 3.7 should work but to be safe if you have the latest version that should work

2. Extract the Files in this zip to somewhere else on your drive

3. open terminal and type 'pip install tesserocr-2.4.0-cp37-cp37m-win_amd64.whl'
if you arent running windows format the pip install how your OS usually does it i dont know if this will even work without windows but whatever

4. Get a .jpg image that you want to convert to text and drop it into the new file with everything else
it doesn't necessarily matter where the image is, as long as the image is in the same folder as pic2text.py

5. open pic2text.py and type in the missing information
missing information is really just filenames and the path to /tessdata/ which is just inside the tessdata-files folder
your path should end with '/tessdata-files/tessdata/'

6. run and you should see a .txt file with the converted text in the folder

lmk if you have any problems in the groupchat

-Steven Abouchedid