from tesserocr import PyTessBaseAPI
fle = 'PICTURE NAME HERE'
#Dont incllude the file type, just use the name and make sure the picture is
#a .jpg and is in the same folder as this file
#If not a jpeg, comment out the next line and include the file type in the 'fle' variable
images = [fle +'.jpg']
with PyTessBaseAPI(path='*ENTER PATH TO /tessdata/ HERE*', lang='eng') as api:
    for img in images:
        api.SetImageFile(img)
        text = api.GetUTF8Text()
f = open(fle+'.txt', 'a')
f.write(text)
f.close()